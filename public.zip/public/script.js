// Fetch and display events based on city search
async function searchEvents(e) {
    e.preventDefault();
    const city = document.getElementById('search-input').value.trim(); // Get city name
    if (!city) {
        alert('Please enter a city name.');
        return;
    }

    try {
        // Fetch events from the backend
        const response = await fetch(`/api/events?city=${city}`);
        const events = await response.json();

        const eventsDiv = document.getElementById('events');
        eventsDiv.innerHTML = ""; // Clear previous results

        if (events.length > 0) {
            events.forEach(event => {
                eventsDiv.innerHTML += `
                    <div class="event-card">
                        <h3>${event.title}</h3>
                        <p><strong>Category:</strong> ${event.category}</p>
                        <p><strong>City:</strong> ${event.city}</p>
                        <p>${event.description}</p>
                    </div>
                `;
            });
        } else {
            eventsDiv.innerHTML = "<p>No events found for this city.</p>";
        }
    } catch (error) {
        console.error('Error fetching events:', error);
    }
}

// Attach the searchEvents function to the form submit
document.getElementById('search-form').addEventListener('submit', searchEvents);
